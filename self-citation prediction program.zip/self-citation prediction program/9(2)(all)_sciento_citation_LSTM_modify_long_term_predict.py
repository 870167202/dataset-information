# -*- coding: utf-8 -*-
# predict one-year citations

import numpy as np
from numpy import random
from scipy.stats import powerlaw
from tensorflow.keras.models import load_model
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

import os
tf.compat.v1.disable_eager_execution()
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
print('GPU: ', tf.test.is_gpu_available())


file_test = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                 r'\\citations_time_series_test.txt', 'r', encoding='UTF-8')

cit_data = []
cit_data_1 = []
while True:
    line = file_test.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        cit_data.append(temp)
file_test.close()

# test data
cit_data = np.array(cit_data, dtype=float)
cit_data_unscaled = cit_data.copy()  # 备份 len=15


# 三层
test_5_data = []
for data in cit_data:
    temp = []
    for ele in data:
        temp.append([ele])
    test_5_data.append(temp)
test_5_data = np.array(test_5_data, dtype=float)
print(test_5_data.shape)  # 前5个标准化test数据

# >>>>>>>>>>>>>>>>>>>> modify <<<<<<<<<<<<<<<<<<<<


def modify(num):
    alpha = 0.38  # α<1, α越大, α-1越接近0，尾部越厚 0.2 数量分布头部拟合较好
    if num == 0:      # 对于历史自引数为0的论文 赋予其一个随机0到1之间的历史值，使其有可能在未来接收到self-citations
        num = powerlaw.rvs(alpha, loc=0, scale=1, size=1)  # 在 [0, 1) 的均匀分布中产生随机数。
        num = np.round(num)
    s = 3.0 * num ** 1.20  # beta1=3.7 beta2=1.21 alpha=0.2
    r = powerlaw.rvs(alpha, loc=0, scale=s, size=1)
    return np.round(r)

# >>>>>>>>>>>>>>>>>>>> modify <<<<<<<<<<<<<<<<<<<<


model = load_model('E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                   '\\LSTM_model_3.h5')
predicted = model.predict(test_5_data[:, :6], batch_size=256)  # 由前5年预测第6年

predicted_unscaled = [np.round(x) for item in predicted for x in item]  # 保存所有（标准化）预测值
print(len(predicted_unscaled))
predicted_unscaled = np.array(predicted_unscaled, dtype=float)

# predicted_unscaled = cit_data_unscaled[:, 5]

count = 0
delta = predicted_unscaled - cit_data_unscaled[:, 5]
print(delta[200:230])
for i in range(len(predicted_unscaled)):
    delta = predicted_unscaled[i] - cit_data_unscaled[i][5]

    if delta < 0:
        count += 1
        predicted_unscaled[i] = cit_data_unscaled[i][5]
    else:
        temp = modify(delta)
        # temp = random.poisson(lam=temp)
        predicted_unscaled[i] = cit_data_unscaled[i][5] + temp
print('count: %s' % count)
predicted_unscaled.transpose()
predicted_unscaled_array = predicted_unscaled.copy()  # 整数

for y in range(1, 9):
    print('y: %d' % y)

    cit_data_unscaled = np.c_[cit_data_unscaled[:, 1:6], predicted_unscaled]
    # 三层
    test_6_data = []
    for data in cit_data_unscaled:
        temp = []
        for ele in data:
            temp.append([ele])
        test_6_data.append(temp)
    test_6_data = np.array(test_6_data, dtype=float)

    predicted = model.predict(test_6_data, batch_size=256)
    predicted_unscaled = [np.round(x) for item in predicted for x in item]
    print('len(predicted_unscaled): %s' % len(predicted_unscaled))
    predicted_unscaled = np.array(predicted_unscaled, dtype=float)
    count = 0  # 计数delta小于0的个数
    for i in range(len(predicted_unscaled)):
        delta = predicted_unscaled[i] - cit_data_unscaled[i][-1]
        if delta < 0:
            count += 1
            predicted_unscaled[i] = cit_data_unscaled[i][-1]
        else:
            temp = modify(delta)
            # temp = random.poisson(lam=temp)
            predicted_unscaled[i] = cit_data_unscaled[i][-1] + temp

    print('count: %s' % count)

    predicted_unscaled.transpose()
    predicted_unscaled_array = np.c_[predicted_unscaled_array, predicted_unscaled]
    print(predicted_unscaled_array.shape)

# scaled_array = np.c_[cit_data_scaled_1[:, :6], predicted_scaled_list]
# unscaled_array = inverse_score(train_mean, train_std, scaled_array)
# predicted_unscaled_array = unscaled_array[:, 6:]
for y in range(0, 9):
    f_out = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                 r'\\LSTM_modify_predict\\LSTM_modify_predict_NO_' + str(y) + 'th_citations_test.txt', 'w',
                 encoding='UTF-8')
    for item in predicted_unscaled_array[:, y]:
        f_out.write('%.2f\n' % item)
    f_out.close()


