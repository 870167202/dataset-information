# -*- coding: utf-8 -*-
import os

path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
files = os.listdir(path)
for file in files:
    full_path = os.path.join(path, file)
    print("full_path: ", full_path)
    fin = open(full_path + '\\citations_matrix.txt', 'r', encoding='UTF-8')
    fout = open(full_path + '\\citations_matrix_cumulative_counts.txt', 'w', encoding='UTF-8')
    count = 0
    while True:
        c = fin.readline()
        if c == '':
            break
        c = c.strip()
        data = c.split()  # 以空格划分成list

        data_cum = [int(data[0])]
        for num in range(1, len(data)):
            data_cum.append(int(data_cum[-1]) + int(data[num]))
        for i in range(len(data_cum)):
            if i != len(data) - 1:
                fout.write('%s\t' % data_cum[i])
            else:
                fout.write('%s\n' % data_cum[i])
        count += 1

    fin.close()
    fout.close()
