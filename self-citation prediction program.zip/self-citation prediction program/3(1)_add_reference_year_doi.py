# -*- coding: utf-8 -*-
import os

path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
files = os.listdir(path)
for file in files:
    full_path = os.path.join(path, file)
    print("full_path: ", full_path)
    fin = open(full_path + '\\paper_references.txt', 'r', encoding='UTF-8')
    fin2 = open(full_path + '\\paper_year_doi.txt', 'r', encoding='UTF-8')
    fout = open(full_path + '\\reference_year_doi.txt', 'a+', encoding='UTF-8')  # 追加

    # print(len(fin2.readlines()))
    list_fin2 = fin2.read()
    fin2.seek(0)
    print(type(list_fin2))
    print(len(list_fin2))


    def indexstr(str1, str2):
        # 查找指定字符串str1包含指定子字符串str2的全部位置，以列表形式返回
        lenth2 = len(str2)
        lenth1 = len(str1)
        indexstr2 = []
        i = 0
        while str2 in str1[i:]:
            indextmp = str1.index(str2, i, lenth1)
            indexstr2.append(indextmp)
            i = (indextmp + lenth2)
        return indexstr2


    list_fout = 0
    count = 0
    while True:
        c = fin.readline()
        fout.seek(0)
        list_fout = fout.read()

        if c == '':
            break
        c = c.strip()  # 去除首尾空格
        ind_doi = indexstr(c, 'DOI ')  # 出现的所有位置
        del_list = []
        # 特殊情况 DOI [..., DOI ...]、DOI [...,...]、DOI [DOI ...,...]
        if ', DOI' in c:
            ind_symbol = indexstr(c, ', DOI')
            for i in ind_symbol:
                ind_doi.remove(i + 2)

        if '[DOI ' in c:
            ind_bracket = indexstr(c, '[DOI ')
            for i in ind_bracket:
                ind_doi.remove(i + 1)

        # print(ind_doi)
        # print(len(ind_doi))
        # 遍历所有位置
        m = 0
        while m < len(ind_doi):
            if m == len(ind_doi) - 1:
                str_doi = c[ind_doi[m] + 4:]
                # print(str_doi)
            else:
                str_doi = c[ind_doi[m] + 4:ind_doi[m + 1] - 5]
                # print(str_doi)
            str_doi = str_doi.strip()
            if str_doi not in list_fin2 and str_doi not in list_fout:
                print('---------- Not exist -----------')
                print(str_doi)
                fout.write('%s\t' % c[ind_doi[m] - 5:ind_doi[m] - 1])
                fout.write('%s\n' % str_doi)
            fout.seek(0)
            list_fout = fout.read()
            m = m + 1
        count = count + 1

    print(count)
    fin.close()
    fin2.close()
    fout.close()
