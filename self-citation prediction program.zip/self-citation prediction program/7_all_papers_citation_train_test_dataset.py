# -*- coding: utf-8 -*-

data_set = ['test', 'training']
journal_set = ['SCIENTOMETRICS', 'Jasist', 'EUROPEAN JOURNAL OF INFORMATION SYSTEMS', 'INFORM MANAGE-AMSTER',
               'INFORM PROCESS MANAG', 'INFORM SCIENCES', 'INFORMATION TECHNOLOGY AND LIBRARIES',
               'INTERNATIONAL JOURNAL OF GEOGRAPHICAL INFORMATION SCIENCE', 'JOURNAL OF INFORMATION SCIENCE',
               'JOURNAL OF INFORMATION TECHNOLOGY', 'JOURNAL OF MANAGEMENT INFORMATION SYSTEMS',
               'JOURNAL OF THE AMERICAN MEDICAL INFORMATICS ASSOCIATION', 'ONLINE INFORMATION REVIEW',
               'SOCIAL SCIENCE COMPUTER REVIEW', 'Journal of the Association for Information Systems',
               'TELECOMMUNICATIONS POLICY', 'JOURNAL OF STRATEGIC INFORMATION SYSTEMS']

for i in data_set:
    content = ''
    for j in journal_set:
        print(j)
        fin = open(r"E:\\dudu\\program_data\Dataset\\InformationScience\\" + j + r"\citations_time_series_" + i + ".txt",
                   'r',
                   encoding='UTF-8')
        content = content + fin.read()
        fin.close()
    fout = open(
        r"E:\dudu\program_data\Dataset\InformationScience\all_journals_data\citations_time_series_" + i + ".txt", 'w',
        encoding='UTF-8')
    fout.write('%s' % content)
    fout.close()
