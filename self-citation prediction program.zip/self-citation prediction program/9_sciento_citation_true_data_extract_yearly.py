# -*- coding: utf-8 -*-

import numpy as np
from sklearn.preprocessing import StandardScaler

fin = open(r'E:\\dudu\\program_data\\Dataset\\InformationScience\\all_journals_data\\citations_time_series_test.txt',
           'r', encoding='UTF-8')
file_train = open(r'E:\\dudu\\program_data\\Dataset\\InformationScience\\all_journals_data'
                  r'\\citations_time_series_training.txt', 'r', encoding='UTF-8')
train_data = []
while True:
    line = file_train.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        train_data.append(temp)
file_train.close()
train_data = np.array(train_data, dtype=float)
print(train_data.shape)

cit_data = []

while True:
    line = fin.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        cit_data.append(temp)

fin.close()

cit_data = np.array(cit_data, dtype=float)
len_item = len(cit_data[0])
print(len_item)

for y in range(6, len_item):
    year = y - 6
    f_out = open(r'E:\dudu\program_data\Dataset\InformationScience\all_journals_data\True_citation_yearly\\'
                 r'unscaled_true_NO_' + str(year) + 'th_citations_test.txt', 'w', encoding='UTF-8')
    for p in cit_data[:, y]:
        f_out.write('%f\n' % p)
    f_out.close()

# 标准化 # inverse_transform() 反转为原始比例数据
scaler = StandardScaler()
scaler = scaler.fit(train_data)
cit_data = scaler.transform(cit_data)
print(cit_data[0])

for y in range(6, len_item):
    y = y - 6
    f_out = open(r'E:\dudu\program_data\Dataset\InformationScience\all_journals_data\True_citation_yearly\\'
                 r'scaled_true_NO_' + str(y) + 'th_citations_test.txt', 'w', encoding='UTF-8')
    for p in cit_data[:, y]:
        f_out.write('%f\n' % p)
    f_out.close()

