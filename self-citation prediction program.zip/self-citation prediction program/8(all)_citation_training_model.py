# -*- coding: utf-8 -*-

import matplotlib.pyplot as plt
import numpy as np
from numpy import random
from tensorflow.keras import models, optimizers, regularizers
from tensorflow.keras.layers import LSTM, Dense, Activation, Dropout, BatchNormalization, ReLU, ELU, LeakyReLU
from tensorflow.keras.callbacks import LearningRateScheduler, ReduceLROnPlateau, EarlyStopping
import tensorflow.keras.backend as K
from matplotlib.backends.backend_pdf import PdfPages
import tensorflow as tf
from math import floor, pow
import os
tf.compat.v1.disable_eager_execution()
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
print('GPU: ', tf.test.is_gpu_available())
# gpu_options = tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.333)
# sess = tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gpu_options))

my_lr = 0.02
epochs = 100
lr_power = 1.2


# 深度深比宽度宽的模型更优
def build_model():
    model = models.Sequential()  # 序贯模型 多个网络层的线性堆叠
    # input_shape指定序列的长度 （8，1）长度8 维度1
    # 默认activation=tanh
    model.add(LSTM(512, input_shape=(6, 1), kernel_regularizer=regularizers.l2(0.1), return_sequences=False))
    # 防止过拟合，20%的神经元不工作
    model.add(Dropout(0.2))
    # model.add(LSTM(64, activation='relu'))
    # 默认False，控制返回类型。若为True则返回整个序列，否则仅返回输出序列的最后一个输出
    # Dense层默认无activation
    model.add(Dense(units=1))
    # 数据归一化方法，往往用在深度神经网络中激活层之前,可以加快模型训练时的收敛速度
    # 所实现的运算是output = activation(dot(input, kernel)+bias)
    # 卷积神经网络中，卷积层的输出，一般使用ReLu作为激活函数，因为可以有效避免梯度消失，并且线性函数在计算性能上面更加有优势。
    # 而循环神经网络中的循环层一般为tanh，或者ReLu，全连接层也多用ReLu，
    # 只有在神经网络的输出层，使用全连接层来分类的情况下，才会使用softmax这种激活函数
    model.add(LeakyReLU(alpha=0.4))  # 0.4时 loss=0.038
    # model.add(layers.advanced_activations.LeakyReLU(alpha=0.5))  # 激活因子
    my_optimizer = optimizers.RMSprop(learning_rate=my_lr)
    model.compile(optimizer=my_optimizer, loss='mse', metrics=['accuracy'])

    # （L1损失）mae:平均绝对误差 （L2损失）mse：均方误差
    model.summary()
    return model


drop = 8
factor = 0.6


def scheduler(epoch):
    # exponential decay
    decay = pow(factor, floor(1 + epoch / drop))
    alpha = my_lr * decay
    return alpha


lr_new = LearningRateScheduler(scheduler)


fin1 = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
            r'\\citations_time_series_training.txt', 'r', encoding='UTF-8')
cit_data_0 = []
cit_data_1 = []

while True:
    line = fin1.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        # if int(data[4]) > 20:
        #     continue
        cit_data_0.append(data[:])

fin1.close()

cit_data_0 = np.array(cit_data_0, dtype=int)

for i in range(len(cit_data_0)):
    temp = []
    for j in cit_data_0[i]:
        temp.append([j])
    cit_data_1.append(temp)

random.shuffle(cit_data_1)   # 打乱

train_data = []
train_target = []

count = 0
for m in cit_data_1:
    count += 1
    train_list = list(m)
    if count == 1:
        print(train_list)
    for i in range(0, len(train_list) - 6):  # 15个数据 窗口大小7（6输入1输出） 可移动9次
        train_data.append(train_list[i:i + 6])
        train_target.append(train_list[i + 6])

print(len(train_data), len(train_data[0]), len(train_target), len(train_target[0]))
print(train_data[0])
print(train_target[0])
train_data = np.array(train_data, dtype=int)
train_targets = np.array(train_target, dtype=int)

model = build_model()
history = model.fit(train_data, train_targets, epochs=epochs, batch_size=64, callbacks=[lr_new], verbose=2)
loss, acc = model.evaluate(train_data, train_targets, verbose=1)
print("Val loss: ", loss)
print("Val accuracy: ", acc)

model.save('E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data\\LSTM_model_3.h5')
