# -*- coding: utf-8 -*-

fin1=open(r'E:\dudu\program_data\Dataset\InformationScience\INFORMATION TECHNOLOGY AND LIBRARIES\paper_year.txt','r', encoding='UTF-8')
fin2=open(r'E:\dudu\program_data\Dataset\InformationScience\INFORMATION TECHNOLOGY AND LIBRARIES\paper_doi.txt','r', encoding='UTF-8')
fout1=open(r'E:\dudu\program_data\Dataset\InformationScience\INFORMATION TECHNOLOGY AND LIBRARIES\paper_year_doi.txt','w', encoding='UTF-8')

while True:

    c1 = fin1.readline()
    if c1 == '':
        break
    c1 = c1.strip()   # 去除首尾空格
    fout1.write('%s\t' % c1)

    c2 = fin2.readline()
    if c2 == '':
        break
    c2 = c2.strip()  # 去除首尾空格
    fout1.write('%s\n' % c2)

fin1.close()
fin2.close()
fout1.close()
