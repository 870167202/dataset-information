# -*- coding: utf-8 -*-

import numpy as np

fin = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
           r'\\citations_time_series_test.txt', 'r', encoding='UTF-8')

cit_data = []

while True:
    line = fin.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        cit_data.append(temp)

fin.close()

cit_data = np.array(cit_data, dtype=float)
len_item = len(cit_data[0])
print(len_item)

for y in range(6, len_item):
    year = y - 6
    f_out = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\all_journals_data\True_citation_yearly'
                 r'\\true_NO_' + str(year) + 'th_citations_test.txt', 'w', encoding='UTF-8')
    for p in cit_data[:, y]:
        f_out.write('%f\n' % p)
    f_out.close()



