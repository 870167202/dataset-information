# -*- coding: utf-8 -*-
# predict one-year citations

import numpy as np
from numpy import random
from scipy.stats import powerlaw
from tensorflow.keras.models import load_model
import tensorflow as tf
from sklearn.preprocessing import StandardScaler

import os
tf.compat.v1.disable_eager_execution()
os.environ["CUDA_VISIBLE_DEVICES"] = "1"
print('GPU: ', tf.test.is_gpu_available())

file_test = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                 r'\\citations_time_series_test.txt', 'r', encoding='UTF-8')
file_train = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                  r'\\citations_time_series_training.txt', 'r', encoding='UTF-8')
train_data = []
while True:
    line = file_train.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        train_data.append(temp)
file_train.close()
train_data = np.array(train_data, dtype=float)
print(train_data.shape)

cit_data = []
cit_data_1 = []
while True:
    line = file_test.readline().strip()
    if line == '':
        break
    else:
        data = line.split()
        temp = []
        for c in data:
            temp.append(int(c))
        cit_data.append(temp)
file_test.close()

cit_data = np.array(cit_data, dtype=float)
cit_data_unscaled = cit_data  # 备份 len=15

# 三层
test_6_data = []
for data in cit_data:
    temp = []
    for ele in data:
        temp.append([ele])
    test_6_data.append(temp)
test_6_data = np.array(test_6_data, dtype=float)
print(test_6_data.shape)  # 前5个标准化test数据

model = load_model('E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data'
                   '\\LSTM_model_3.h5')
predicted = model.predict(test_6_data[:, 0:6], batch_size=256)  # 由前6年预测第7年
predicted_unscaled = [np.round(x) for item in predicted for x in item]  # 保存0th（标准化）预测值
#
predicted_unscaled = np.array(predicted_unscaled, dtype=float)
predicted_list = predicted_unscaled
predicted_unscaled.transpose()
print(predicted_unscaled.shape)
print(predicted_list.shape)

for y in range(1, 9):
    print(y)

    cit_data_unscaled = np.c_[cit_data_unscaled[:, 1:6], predicted_unscaled]

    test_6_data = []
    for data in cit_data_unscaled:
        temp = []
        for ele in data:
            temp.append([ele])
        test_6_data.append(temp)
    test_6_data = np.array(test_6_data, dtype=float)

    predicted = model.predict(test_6_data, batch_size=256)
    predicted_unscaled = [np.round(x) for item in predicted for x in item]

    predicted_unscaled = np.array(predicted_unscaled, dtype=float)
    predicted_unscaled.transpose()
    predicted_list = np.c_[predicted_list, predicted_unscaled]
    print(predicted_list.shape)

for y in range(0, 9):
    f_out = open(r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\\all_journals_data\\LSTM_predict'
                 r'\\LSTM_predict_NO_' + str(y) + 'th_citations_test.txt', 'w', encoding='UTF-8')
    for item in predicted_list[:, y]:
        f_out.write('%.3f\n' % item)
    f_out.close()
