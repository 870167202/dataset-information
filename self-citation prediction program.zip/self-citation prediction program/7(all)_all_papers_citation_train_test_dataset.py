# -*- coding: utf-8 -*-
import os

data_set = ['test', 'training']

for i in data_set:
    content = ''
    path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
    files = os.listdir(path)
    for file in files:
        full_path = os.path.join(path, file)
        print("full_path: ", full_path)
        fin = open(full_path + '\\citations_time_series_' + i + ".txt", 'r', encoding='UTF-8')
        content = content + fin.read()
        fin.close()
    fout = open(
        r"E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new_2\all_journals_data\citations_time_series_" + i +
        ".txt", 'w', encoding='UTF-8')
    fout.write('%s' % content)
    fout.close()
