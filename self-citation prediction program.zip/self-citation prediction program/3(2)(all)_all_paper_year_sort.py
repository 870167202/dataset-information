# -*- coding: utf-8 -*-
import os

path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
files = os.listdir(path)
for file in files:
    full_path = os.path.join(path, file)
    print("full_path: ", full_path)
    fin1 = open(full_path + '\\paper_year_doi.txt', 'r+', encoding='UTF-8')
    fin2 = open(full_path + '\\reference_year_doi.txt', 'r', encoding='UTF-8')  # 追加
    count = 0
    count1 = 0
    content = fin1.read()
    print(len(content))
    fin1.seek(0)

    lines = fin1.readlines()  # 读取所有行
    fin1.seek(0)
    last_line = lines[-1]  # 取最后一行
    min_year = int(last_line[:4])  # paper_year_doi.txt中最小年份
    print(min_year)
    while True:
        c2 = fin2.readline()
        # c2 = c2.replace('\n', '').replace('\r', '')
        y2 = c2[:4]
        # c2 = '\n'+c2
        # print(c2)       # year doi\n
        if c2 == '':
            break

        # print(y2)       # year
        content = fin1.read()
        fin1.seek(0)
        len_str = 0  # 获取内容长度 便于定位插入新内容
        while True:
            c1 = fin1.readline()
            len_str += len(c1)
            # print(c1[:4])
            # cur_year =
            count += 1
            # 最小年份，末尾追加
            if int(y2) < min_year:
                min_year = int(y2)
                # print('min_year:'+str(min_year))
                content = content + c2
                fin1.seek(0)
                fin1.write(content)
                fin1.seek(0)
                break
            # 中间插入
            if int(y2) >= int(c1[:4]):
                # print(c1[:4])
                # print(c2)   # 2017	[10.1007/s11192-011-0445-3, DOI 10.1007/s11192-017-2250-0]
                content = content[:len_str - len(c1)] + c2 + content[len_str - len(c1):]
                # print(content)
                fin1.seek(0)
                fin1.write(content)  # c1 = fin1.readline()指针已经不在第一行
                fin1.seek(0)
                break

        # print(count)    # 1144
        count = 0
        count1 += 1

    fin1.close()
    fin2.close()

