# -*- coding: utf-8 -*-

fin1 = open(r'E:\dudu\program_data\Dataset\InformationScience\EUROPEAN JOURNAL OF INFORMATION SYSTEMS\paper_year_doi.txt','r', encoding='UTF-8')   # 430092
fin2 = open(r'E:\dudu\program_data\Dataset\InformationScience\EUROPEAN JOURNAL OF INFORMATION SYSTEMS\citations_matrix_cumulative_counts.txt', 'r', encoding='UTF-8')
fout1 = open(r'E:\dudu\program_data\Dataset\InformationScience\EUROPEAN JOURNAL OF INFORMATION SYSTEMS\citations_time_series_test.txt', 'w', encoding='UTF-8')
fout2 = open(r'E:\dudu\program_data\Dataset\InformationScience\EUROPEAN JOURNAL OF INFORMATION SYSTEMS\citations_time_series_training.txt', 'w', encoding='UTF-8')

# Sciento:   training:1978-2003, test:2004-2007
# Jasist:    training:2001-2003, test:2004-2007
# Informetr: training: no, test:2007
# INFORM MANAGE-AMSTER training:1989-2003, test:2004-2007
# INFORM PROCESS MANAG training:1975-2003, test:2004-2007
# INFORM SCIENCES      training:1968-2003, test:2004-2007
# MIS QUART            training:1980-2003, test:2004-2007
# Nature training: 1990-2003, test: 2004-2007

paper_doi = []
paper_year = []

# 获取所有paper doi year
while True:
    c1 = fin1.readline()
    if c1 == '':
        break
    c1 = c1.strip()
    year = c1[:4]
    doi = c1[5:]
    paper_doi.append(doi)
    paper_year.append(year)
print(len(paper_year))  # 6134
print(len(paper_doi))   # 6134
fin1.seek(0)
test_last_year_index = paper_year.index('2006')   # 仅考虑发表日期在2007年及以前的paper的self-citations序列
print(test_last_year_index)  # 2672               # 确保序列中前5项作为模型输入，后9项作为预测的目标
train_last_year_index = paper_year.index('2004')  # 根据各期刊论文集内的数据量划分成两个子集，分别用于后续的训练和测试
print(train_last_year_index)    #
# divide_test_year_index = paper_year.index('1969')

# 1978-2008 2009-2013
count = 0
citation_total_list = []  # 检查序列
max_year = 2006  # 仅考虑发表日期在2007年及以前的paper的self-citations序列 2004-2007年发表的paper用于测试
mid_year = 2004  # 1995-2003年发表的paper用于训练
min_year = 1991
max_year_index = max_year - min_year
mid_year_index = mid_year - min_year

while True:
    count += 1
    c2 = fin2.readline()
    if c2 == '' or count == len(paper_doi):
        break
    if count <= test_last_year_index:  # 仅考虑发表日期在2007年及以前的paper
        continue
    else:
        c2 = c2.strip()
        citations = c2.split()  # paper的累积citation序列
        citation_list = []
        print(count)
        # pub_year = paper_year[count]    # paper发表年份
        # pub_index = int(pub_year) - min_year     # paper发表年份对应的list索引
        # 以上两步考虑的是 所有序列都是从发表当年开始 可以考虑 从发表若干年后开始序列

        if count <= train_last_year_index:
            # test window size 14, use previous 5 counts to predict future 9 counts
            for n in range(max_year_index, max_year_index + 15):
                citation_list.append(int(citations[n]))
                if n < max_year_index + 14:
                    fout1.write('%s\t' % citations[n])
                else:
                    fout1.write('%s\n' % citations[n])
        elif train_last_year_index < count:
            # training window size 6, 5 counts and 1 target count
            # 以JOURNAL OF STRATEGIC INFORMATION SYSTEMS为例，
            # 1995-2003年发表的paper 可以考虑将每个paper的总序列划分成2003-2008、2009-2014、2015-2020三组，充分利用数据集
            # for i in range(0, 1):
            #     for n in range(mid_year_index + 7*i, mid_year_index + 7*(i+1)):
            #         citation_list.append(int(citations[n]))
            #         if n < mid_year_index + 7*(i+1) - 1:
            #             fout2.write('%s\t' % citations[n])
            #         else:
            #             fout2.write('%s\n' % citations[n])
            for n in range(mid_year_index, mid_year_index + 15):
                citation_list.append(int(citations[n]))
                if n < mid_year_index + 14:
                    fout2.write('%s\t' % citations[n])
                else:
                    fout2.write('%s\n' % citations[n])
        citation_total_list.append(citation_list)

print(citation_total_list[:10])
fin1.close()
fin2.close()
fout1.close()
fout2.close()

