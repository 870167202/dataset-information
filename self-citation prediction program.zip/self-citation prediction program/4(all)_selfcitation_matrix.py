# -*- coding: utf-8 -*-
import os


# 初始化list 长度20（2001-2013）
def cit_num_clean():
    for i in range(len(cit_num)):
        cit_num[i] = 0


path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
files = os.listdir(path)
for file in files:
    full_path = os.path.join(path, file)
    print("full_path: ", full_path)
    fin1 = open(full_path + '\\paper_year_doi.txt', 'r', encoding='UTF-8')
    fin2 = open(full_path + '\\paper_references.txt', 'r', encoding='UTF-8')
    fout = open(full_path + '\\citations_matrix.txt', 'w', encoding='UTF-8')

    paper_doi = []
    paper_year = []

    # 获取所有paper doi year
    while True:
        c = fin1.readline()
        if c == '':
            break
        c = c.strip()
        year = c[:4]
        doi = c[5:]
        # if int(year) >= 1970:   # 只考虑1970-2020的paper引文信息
        paper_doi.append(doi)
        paper_year.append(year)

    fin1.close()
    print(len(paper_doi), len(paper_year))

    time_gap = int(paper_year[0]) - int(paper_year[-1]) + 1
    cit_num = [0] * time_gap  # paper_year_doi.txt 最大时间间隔
    print(cit_num)

    count = 0
    row = 0  # 遍历行数
    min_year = int(paper_year[-1])

    # p： 被引paper索引 row：引用索引
    cit_num_clean()
    for p in range(len(paper_doi)):
        row = 0
        while True:
            c = fin2.readline()
            if c == '':
                break
            c = c.strip()
            if int(paper_year[p]) <= int(paper_year[row]):  # ref year <= paper year
                if paper_doi[p] in c:
                    cit_num[int(paper_year[row]) - min_year] += 1
            row += 1
        for j in range(len(cit_num)):
            if j == len(cit_num) - 1:
                fout.write('%s\n' % cit_num[j])
            else:
                fout.write('%s\t' % cit_num[j])
        cit_num_clean()  # 清零
        fin2.seek(0)

    fin2.close()
    fout.close()
