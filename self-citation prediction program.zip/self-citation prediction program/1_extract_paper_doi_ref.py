# -*- coding: utf-8 -*-
# only consider "Article", not "Editorial Material"


fin=open(r'E:\dudu\program_data\Dataset\InformationScience\MIS QUART\all.txt','r', encoding='UTF-8')   # 430092
fout_doi=open(r'E:\dudu\program_data\Dataset\InformationScience\MIS QUART\paper_doi.txt','w',
              encoding='UTF-8')
fout_year=open(r'E:\dudu\program_data\Dataset\InformationScience\MIS QUART\paper_year.txt','w',
               encoding='UTF-8')
fout = open(r'E:\dudu\program_data\Dataset\InformationScience\MIS QUART\paper_references.txt', 'w',
            encoding='UTF-8')
# fout_ref = open(r'D:\dududu\Dataset\PNAS_Nature_Science\NATURE\ref_without_doi.txt', 'w',
#                 encoding='UTF-8')

paper_num = 0
paper_doi = []
paper_year = []
mark_year = False   # 标记是否已遍历paper的year
mark_paper = False  # 标记是否开始一篇paper
mark_PY = False     # 标记是否记录了PY year
paper_doi_exist = False  # 标记paper是否有doi
paper_doi_repeat = False    # 标记paper doi是否重复
ref_year_doi = ''   # 参考文献year doi
year_content = 0
len_year = 0
count = 0
count_ref = 0
year = 0
while True:
    count = count + 1
    c = fin.readline()
    if c == '':
        break
    c = c.strip()   # 去除首尾空格
    if c == 'PT J':    # 开始paper信息
        mark_year = False
        paper_doi_exist = False
        paper_doi_repeat = False
        mark_PY = False
        ref_year_doi = ''
        year = 0
        continue

    # extract references

    if c[:3] == 'CR ':  # 遍历paper reference
        y = 0

        if ', MIS QUART,' in c:
            ind1 = c.index(', MIS QUART,')  # find year
            y = c[ind1 - 4:ind1]

            if ' DOI ' in c:
                # 'DOI DOI '去重
                if 'DOI DOI ' in c:
                    ind2 = c.index('DOI DOI ')
                    b = c[ind2 + 4:]  # doi
                else:
                    ind2 = c.index('DOI ')
                    b = c[ind2:]
                b = b.strip()
                if b[-1] == ' ':
                    b[-1] = '\t'
                # fout.write('%s\t' % y)  # year
                # fout.write('%s\t' % b)
                ref_year_doi = y + '\t' + b + '\t'
            # elif 1990 <= int(y) <= 2015:
            #     print(count)
            #     fout_ref.write('%s%s\n' % (count, c))

        while True:
            count += 1
            c1 = fin.readline()
            y = 0
            if c1[:3] == 'NR ':
                # fout.write('\n')
                ref_year_doi = ref_year_doi + '\n'
                break
            if ', MIS QUART,' in c1:
                ind3 = c1.index(', MIS QUART,')  # find year
                y = c1[ind3 - 4:ind3]

                if ' DOI ' in c1:
                    ind4 = c1.index('DOI ')
                    # 'DOI DOI '去重
                    if 'DOI DOI ' in c1:
                        ind4 = c1.index('DOI DOI ')
                        b = c1[ind4 + 4:]  # doi
                    else:
                        ind4 = c1.index('DOI ')
                        b = c1[ind4:]
                    b = b.strip()
                    if b[-1] == ' ':
                        b[-1] = '\t'
                    ref_year_doi = ref_year_doi + y + '\t' + b + '\t'
                # elif 1990 <= int(y) <= 2015:
                #     print(count)
                #     fout_ref.write('%s%s\n' % (count, c1))

        continue
    if c == 'NR 0':  # without reference
        # fout.write('\n')
        ref_year_doi = '\n'
    if c[:3] == 'PY ' and len(c) == 7:  # paper发表日期
        year = c.replace('PY ', '')  # 去除'PY '
        year = year.strip()
        paper_year.append(year)
        mark_PY = True
        continue

    if c[:3] == 'EA ' and len(c) <= 11 and not mark_PY:       # EA 在DI之后出现 PY 在DI之前
        year = c[-4:]
        year = year.strip()
        paper_year.append(year)
        # mark_year = True
        continue

    if c[:3] == 'DI ' and ',' not in c:  # DI 10.1007/s11192-020-03678-0
        b = c.replace('DI ', '')  # 去除'DI '
        b = b.strip()
        if b not in paper_doi:
            paper_doi_exist = True
            paper_doi.append(b)
            paper_num = paper_num + 1

    if c == 'ER':
        if not paper_doi_exist:
            del paper_year[-1]
            print('observe ' + paper_doi[-1])
        else:
            fout.write('%s' % ref_year_doi)
            count_ref += 1
        if len(paper_year) != len(paper_doi):   # find error
            print(count)
            break

print(paper_num)    # nature: 50423
print(len(paper_year))
print(len(paper_doi))
print(count_ref)

for i in paper_year:
    fout_year.write('%s\n' % i)
for j in paper_doi:
    fout_doi.write('%s\n' % j)

fin.close()
fout.close()
fout_year.close()
fout_doi.close()
