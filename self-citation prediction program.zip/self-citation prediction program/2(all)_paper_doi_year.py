# -*- coding: utf-8 -*-
import os

path = r'E:\\dudu\\program_data\\WoS_Dataset\\InformationScience_new'
files = os.listdir(path)
for file in files:
    full_path = os.path.join(path, file)
    print("full_path: ", full_path)
    fin1 = open(full_path + '\\paper_year.txt', 'r', encoding='UTF-8')
    fin2 = open(full_path + '\\paper_doi.txt', 'r', encoding='UTF-8')
    fout1 = open(full_path + '\\paper_year_doi.txt', 'w', encoding='UTF-8')

    while True:

        c1 = fin1.readline()
        if c1 == '':
            break
        c1 = c1.strip()  # 去除首尾空格
        fout1.write('%s\t' % c1)

        c2 = fin2.readline()
        if c2 == '':
            break
        c2 = c2.strip()  # 去除首尾空格
        fout1.write('%s\n' % c2)

    fin1.close()
    fin2.close()
    fout1.close()
